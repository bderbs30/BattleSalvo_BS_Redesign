package cs3500.pa04;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * Tests the driver.
 */
class DriverTest {

  @Test
  public void fakeTest() {
    System.out.println("An important message...");
    assertEquals(5, 5);
  }

}