package cs3500.pa04.model.ship;

/**
 * Represents the direction of a ship.
 */
public enum Direction {
  HORIZONTAL, VERTICAL
}
