package cs3500.pa04.model.other;

/**
 * Represents the type of game.
 */
public enum GameType {
  SINGLE, MULTI
}
