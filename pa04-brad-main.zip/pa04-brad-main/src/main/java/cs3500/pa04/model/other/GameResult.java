package cs3500.pa04.model.other;

/**
 * Represents the result of a game.
 */
public enum GameResult {
  WIN, LOSE, DRAW
}
